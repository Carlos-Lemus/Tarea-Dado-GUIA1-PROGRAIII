//aplicacion hecha por Carlos Alfonso Lemus Rodezno LR18001

//Pequeña aplicacion que simula el tiro de un dado 
//el numero de dados es generado de forma aleatoria


public class Dado {

	public static void main(String[] args) {
		
		//instancia a un objeto ventana que contiene todo la aplicacion 
		Ventana v = new Ventana();

	}

}
