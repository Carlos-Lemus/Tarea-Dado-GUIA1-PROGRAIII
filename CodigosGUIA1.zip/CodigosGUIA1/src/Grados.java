//HECHO POR CARLOR ALFONSO LEMUS RODEZNO LR18001

import java.util.*;
import java.util.Scanner;

public class Grados{
	
	public static void main(String[] args) {
		
		final Double PUNTO_CONGELACION = 32.0;
		
		final Double FACTOR_CONVERSION = 9.0/5.0;
		
		Double farenheit, celcius;
		
		Scanner stdin = new Scanner(System.in);
		
		System.out.println ("Digite los grados celcius:");
		
		celcius = stdin.nextDouble();
		
		farenheit = celcius*FACTOR_CONVERSION+PUNTO_CONGELACION;
		
		System.out.println ("Los grados farenheit son:" + farenheit);
	}
}
