//HECHO POR CARLOR ALFONSO LEMUS RODEZNO LR18001

//programa que muestra la suma de dos números
//paquetes de JAVA
import javax.swing.JOptionPane;

public class Suma {

	public static void main ( String args[])
	{
		String primerNumero;
		//primera cadena introducida por el
		// usuario
		String segundoNumero; //segunda cadena introducida por el
		// usuario
		int numero1;
		int numero2;
		int suma;
		//primer numero a sumar
		//segundo numero a sumar
		// suma de numero1 y numero2
		//leer el primer numero del usuario como una cadena
		primerNumero = JOptionPane.showInputDialog( "Escriba el primer entero" );
		//leer el segundo numero del usuario como una cadena
		segundoNumero = JOptionPane.showInputDialog( "Escriba el segundo entero");
		//convertir los numeros de tipo String a tipo int
		numero1 = Integer.parseInt( primerNumero );
		numero2 = Integer.parseInt ( segundoNumero );
		//sumar los numeros
		suma = numero1 + numero2;
		//mostrar el resultado
		JOptionPane.showMessageDialog ( null, "La suma es "+ suma,
		"Resultados", JOptionPane.PLAIN_MESSAGE );
		System.exit (0);
	// terminar aplicación con la ventana
	} // fin de main
} //fin de la clase suma