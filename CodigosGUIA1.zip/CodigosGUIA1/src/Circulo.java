//HECHO POR CARLOR ALFONSO LEMUS RODEZNO LR18001

//pequeña aplicacion que calcula el diametro, circuferencia y area de un circulo

import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class Circulo {

	public static void main(String[] args) {
		
		String ingresoDeRadio;
		int radio;
		double diametro; //diametro
		double cfr; //circuferencia
		double area; //area
		//instancia df que nos ayudara a limitar los decimales de los numeros a 2
		DecimalFormat df = new DecimalFormat("#.00");
		
		//Se ingresan el radio atravez del metodo estatico showInputDialog
		//y se almacena en ingresoDeRadio
		ingresoDeRadio = JOptionPane.showInputDialog("Ingresa el radio ");
		
		//el metodo parseInt es un metodo estatico que convierte un String a un int
		radio = Integer.parseInt(ingresoDeRadio);
		
		diametro = (double)(radio *2); //se calcula el diametro
		
		cfr = Math.PI*diametro; //se calcula la circuferencia
		
		//el metodo pow es metodo que eleva un numero hasta una n potencia
	
		area = Math.PI * Math.pow(radio, 2); //se calcula el area
		
		//se muestra el resultado de las operaciones anteriores atravez 
		//del metodo estatico showMessangeDialog
		JOptionPane.showMessageDialog(null,"Radio: " + radio + "\nDiametro: " + 
									df.format(diametro) + "\nCircuferencia: " 
									+ df.format(cfr) + "\nArea: " + df.format(area));
	}

}
