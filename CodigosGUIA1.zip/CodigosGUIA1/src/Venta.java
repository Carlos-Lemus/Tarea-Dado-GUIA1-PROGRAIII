//HECHO POR CARLOR ALFONSO LEMUS RODEZNO LR18001

// Muestra el costo de la venta de un producto.
import java.util.*;
import java.util.Scanner;

public class Venta{

	public static void main(String[] args) {
		Double precio, costo;
		int cantidad;
		Scanner stdin = new Scanner(System.in);
		System.out.println ("Digite el precio:");
		precio = stdin.nextDouble();
		System.out.println ("Digite la cantidad:");
		cantidad = stdin.nextInt();
		costo = precio * cantidad;
		System.out.println ("La venta es:$" + costo);
	}//main
}//clase