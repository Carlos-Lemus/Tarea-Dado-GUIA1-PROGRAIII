//HECHO POR CARLOR ALFONSO LEMUS RODEZNO LR18001

//HolaFecha.java
import java.util.*;

public class HolaFecha {
	
	public static void main(String[] args) {
		System.out.println ("Hola, hoy es: ");
		System.out.println (new Date());
	}
}