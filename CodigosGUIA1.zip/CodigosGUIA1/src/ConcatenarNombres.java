//HECHO POR CARLOR ALFONSO LEMUS RODEZNO LR18001

//pequeña aplicacion que concatena el nombre con el apellido

import javax.swing.JOptionPane;

public class ConcatenarNombres {

	public static void main(String[] args) {
		
		String nombre;
		String apellido;
		String na;
		
		//Se ingresan el bombre atravez del metodo estatico showInputDialog
		//y se almacena en nombre
		nombre = JOptionPane.showInputDialog("Ingresa el nombre ");
		
		//Se ingresan el apellido atravez del metodo estatico showInputDialog
		//y se almacena en apellido
		apellido = JOptionPane.showInputDialog("Ingresa el radio ");
		
		//se concatena nombre y apellido y se almacena en na
		na = nombre + " " + apellido;
		
		//se muestra el nombre y apellido concatenado con el metodo 
		//estatico showMessangeDialog
		JOptionPane.showMessageDialog(null, na);
		
	}

}
